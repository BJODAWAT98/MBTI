from flask import Flask, request, render_template, url_for
from function import final_output
import os

PEOPLE_FOLDER = os.path.join('static', 'image')

app = Flask(__name__)
app.config["UPLOAD_FOLDER"]=PEOPLE_FOLDER
@app.route("/main")
def home():
    
    return render_template("index.html")

@app.route("/result",methods=["POST"])
def output():
    form_data = request.form
    if form_data == '':
        return render_template("index.html",str_="Input Needed!!!!")
    else:
        data = form_data["text"] 
        status = final_output(data)
        return render_template("index.html",str_=status[0:4])

if __name__ == "__main__":
    app.run(debug=True)
